package com.example.touth;

public class listdata {
    private String x;
    private String y;
    private String id;

    public listdata(String x,String y,String id){
        this.x=x;
        this.y=y;
        this.id=id;
    }
    public String getx(){return x;};
    public String gety(){return y;};
    public String getid(){return id;};
}
